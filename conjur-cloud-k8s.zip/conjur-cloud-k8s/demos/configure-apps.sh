#!/bin/bash

set -a
source "./../.env"
set +a

oc config set-context --current --namespace="$APP_NAMESPACE"

oc delete configmap conjur-connect --ignore-not-found=true

openssl s_client -connect "$CONJUR_MASTER_HOSTNAME":"$CONJUR_MASTER_PORT" \
  -showcerts </dev/null 2> /dev/null | \
  awk '/BEGIN CERTIFICATE/,/END CERTIFICATE/ {print $0}' \
  > conjur.pem

oc create configmap conjur-connect \
  --from-literal CONJUR_ACCOUNT="$CONJUR_ACCOUNT" \
  --from-literal CONJUR_APPLIANCE_URL="$CONJUR_APPLIANCE_URL" \
  --from-literal CONJUR_AUTHN_URL="$CONJUR_APPLIANCE_URL"/authn-jwt/"$CONJUR_AUTHENTICATOR_ID" \
  --from-literal AUTHENTICATOR_ID="$CONJUR_AUTHENTICATOR_ID" \
  --from-literal CONJUR_AUTHN_JWT_SERVICE_ID="$CONJUR_AUTHENTICATOR_ID" \
  --from-literal JWT_TOKEN_PATH=/var/run/secrets/kubernetes.io/serviceaccount/token \
  --from-literal MY_POD_NAMESPACE="$APP_NAMESPACE"\
  --from-file "CONJUR_SSL_CERTIFICATE=conjur.pem"

rm "conjur.pem"

echo "✅ ConfigMap 'conjur-connect' created successfully!"

echo "--------------------------------------------"
echo "Here is the created ConfigMap YAML:"
echo "--------------------------------------------"
oc get configmap conjur-connect -o yaml
echo "--------------------------------------------"

#!/bin/bash

set -a
source "./../../../.env"
set +a

oc config set-context --current --namespace="$APP_NAMESPACE"

oc delete serviceaccount $APP3_SA --ignore-not-found=true
oc create serviceaccount $APP3_SA

oc delete configmap spring-boot-templates --ignore-not-found=true
oc create configmap spring-boot-templates --from-file=demo-app.tpl

echo "🚀 Applying Deployment '$APP3_NAME'..."
envsubst < deployment.yml | oc replace --force -f -

echo "⏳ Waiting for Deployment '$APP3_NAME' to be ready..."
if ! oc rollout status deployment/"$APP3_NAME" --timeout=120s; then
  echo "❌ Deployment $APP3_NAME did not become ready"
  exit 1
fi

echo "✅ Deployment '$APP3_NAME' is ready."

echo "📋 Listing pods:"
oc get pods --selector=app="$APP3_NAME"

oc logs --selector=app="$APP3_NAME" -c configurator

oc exec -it $(oc get pod -l app="$APP3_NAME" -o jsonpath='{.items[0].metadata.name}') \
  -c $APP3_NAME -- cat /opt/secrets/conjur/application.yml
  
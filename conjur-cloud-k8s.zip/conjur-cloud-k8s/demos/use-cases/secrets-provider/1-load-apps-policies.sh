#!/bin/bash

set -a
source "./../../../.env"
set +a

## App01 policies
conjur policy update -b data/$APP_GROUP -f <(envsubst < app-host.yml)
conjur policy update -b data/vault/$APP2_SAFE -f <(envsubst < k8s-hosts-grants.yml)


#!/bin/bash

set -a
source "./../../../.env"
set +a

oc config set-context --current --namespace="$APP_NAMESPACE"

oc delete serviceaccount $APP2_SA --ignore-not-found=true
oc create serviceaccount $APP2_SA

# DB SECRETS
envsubst < k8s-secrets.yml | oc replace --force -f -

# Service account role binding
envsubst < service-account-role.yml | oc replace --force -f -

echo "🚀 Applying Deployment '$APP2_NAME'..."
envsubst < deployment.yml | oc replace --force -f -

echo "⏳ Waiting for Deployment '$APP2_NAME' to be ready..."
if ! oc rollout status deployment/"$APP2_NAME" --timeout=120s; then
  echo "❌ Deployment $APP2_NAME did not become ready"
  exit 1
fi

echo "✅ Deployment '$APP2_NAME' is ready."

echo "📋 Listing pods:"
oc get pods --selector=app="$APP2_NAME"

oc logs --selector=app="$APP2_NAME" -c configurator

oc get secret db-credentials-secrets-provider-for-k8s-sidecar \
  -o jsonpath='{.data.SPRING_DATASOURCE_PASSWORD}' | base64 --decode
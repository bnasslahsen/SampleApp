#!/bin/bash
set -euxo pipefail

JWT_TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)

SESSION_TOKEN=$(curl -s --cacert /usr/lib/ssl/conjur.pem -X POST "$CONJUR_APPLIANCE_URL/authn-jwt/$AUTHENTICATOR_ID/$CONJUR_ACCOUNT/authenticate" \
  -H "Content-Type:application/x-www-form-urlencoded" \
  -H "Accept-Encoding:base64" \
  --data-urlencode "jwt=${JWT_TOKEN}")

SECRET=$(curl -s --cacert /usr/lib/ssl/conjur.pem "$CONJUR_APPLIANCE_URL/secrets/$CONJUR_ACCOUNT/variable/$APP_SECRET_ID" \
  -H "Authorization: Token token=\"$SESSION_TOKEN\"")

echo "Retrieved secret: $SECRET"

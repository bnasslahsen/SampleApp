#!/bin/bash

set -euo pipefail

# Load .env variables
set -a
source "./../../../.env"
set +a

echo "🔧 Setting namespace to '$APP_NAMESPACE'..."
oc config set-context --current --namespace="$APP_NAMESPACE"

oc delete serviceaccount $APP1_SA --ignore-not-found=true
oc create serviceaccount $APP1_SA

echo "♻️ Recreating ConfigMap 'get-secrets'..."
oc delete configmap get-secrets --ignore-not-found=true
oc create configmap get-secrets --from-file=get-secrets.sh

echo "🚀 Applying Deployment '$APP1_NAME'..."
envsubst < deployment.yml | oc replace --force -f -

echo "⏳ Waiting for Deployment '$APP1_NAME' to be ready..."
if ! oc rollout status deployment/"$APP1_NAME" --timeout=120s; then
  echo "❌ Deployment $APP1_NAME did not become ready"
  exit 1
fi

echo "✅ Deployment '$APP1_NAME' is ready."

echo "📋 Listing pods:"
oc get pods --selector=app="$APP1_NAME"

oc logs --selector=app="$APP1_NAME"
